<div style="max-width:720px;">
  <div class="card">
    <div class="card-header"><h5>⚙️ My Farm Profile</h5></div>
    <div class="card-body">
      <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></div>
      <?php endif; ?>

      <form method="post" action="<?php echo site_url('dashboard/profile'); ?>" enctype="multipart/form-data">
        <div style="text-align:center;margin-bottom:24px;">
          <div style="width:80px;height:80px;border-radius:50%;background:var(--green-pale);border:3px solid var(--green-light);display:flex;align-items:center;justify-content:center;font-size:2rem;margin:0 auto 10px;overflow:hidden;" id="logo-preview">
            <?php if (!empty($employer['logo'])): ?><img src="<?php echo base_url($employer['logo']); ?>" style="width:100%;height:100%;object-fit:cover;"><?php else: ?>🏚️<?php endif; ?>
          </div>
          <label style="cursor:pointer;"><span class="btn btn-outline btn-sm">📷 Change Logo</span><input type="file" name="logo" accept="image/*" class="photo-input" data-preview="logo-preview" style="display:none;"></label>
        </div>

        <div class="form-row">
          <div class="form-group"><label class="form-label">Farm / Business Name</label><input type="text" name="farm_name" class="form-control" value="<?php echo htmlspecialchars($employer['farm_name']); ?>" required></div>
          <div class="form-group"><label class="form-label">Contact Person</label><input type="text" name="contact_person" class="form-control" value="<?php echo htmlspecialchars($employer['contact_person']); ?>" required></div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Farm Type</label>
            <select name="farm_type" class="form-control">
              <?php foreach(['Crop Farming','Livestock Farming','Poultry Farming','Fish Farming','Mixed Farming','Plantation','Agro-processing','Other'] as $t): ?>
                <option value="<?php echo $t; ?>" <?php echo $employer['farm_type']===$t?'selected':''; ?>><?php echo $t; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group"><label class="form-label">Farm Size</label><input type="text" name="farm_size" class="form-control" value="<?php echo htmlspecialchars($employer['farm_size']??''); ?>" placeholder="e.g. 50 hectares"></div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">LGA</label>
            <select name="lga" class="form-control">
              <?php foreach($lgas as $l): ?><option value="<?php echo $l; ?>" <?php echo $employer['lga']===$l?'selected':''; ?>><?php echo $l; ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="form-group"><label class="form-label">Business Reg. Number</label><input type="text" name="reg_number" class="form-control" value="<?php echo htmlspecialchars($employer['reg_number']??''); ?>"></div>
        </div>
        <div class="form-group"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="2"><?php echo htmlspecialchars($employer['address']??''); ?></textarea></div>

        <hr style="margin:24px 0;">
        <h6>🔐 Change Password (leave blank to keep current)</h6>
        <div class="form-row">
          <div class="form-group"><label class="form-label">New Password</label><input type="password" name="new_password" class="form-control" placeholder="Min 8 characters" minlength="8"></div>
          <div class="form-group"><label class="form-label">Confirm Password</label><input type="password" name="confirm_password" class="form-control" placeholder="Repeat new password"></div>
        </div>

        <div style="display:flex;gap:12px;justify-content:flex-end;margin-top:16px;">
          <button type="submit" class="btn btn-primary">Save Profile</button>
        </div>
      </form>
    </div>
  </div>
</div>
