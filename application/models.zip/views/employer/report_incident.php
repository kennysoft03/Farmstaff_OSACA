<div style="max-width:700px;">
  <div style="margin-bottom:16px;"><a href="<?php echo site_url('dashboard/worker/'.$worker['id']); ?>" class="btn btn-outline btn-sm">← Back to Profile</a></div>

  <div class="alert alert-warning">
    <strong>⚠️ Important:</strong> Incident reports are reviewed by OSACA administrators before they can affect a worker's official record. Please ensure all information is accurate and truthful. False reports may result in account suspension.
  </div>

  <div class="card">
    <div class="card-header" style="border-left:4px solid var(--danger);">
      <h5 style="color:var(--danger);">⚠️ Report Incident — <?php echo htmlspecialchars($worker['firstname'].' '.$worker['lastname']); ?></h5>
    </div>
    <div class="card-body">
      <form method="post" action="<?php echo site_url('dashboard/worker/'.$worker['id'].'/incident'); ?>" enctype="multipart/form-data">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Incident Type <span style="color:var(--danger);">*</span></label>
            <select name="incident_type" class="form-control" required>
              <option value="">— Select Type —</option>
              <?php foreach(['theft','misconduct','assault','insubordination','negligence','fraud','other'] as $t): ?>
                <option value="<?php echo $t; ?>"><?php echo ucfirst($t); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Severity <span style="color:var(--danger);">*</span></label>
            <select name="severity" class="form-control" required>
              <option value="">— Select Severity —</option>
              <option value="minor">Minor — No lasting impact</option>
              <option value="moderate">Moderate — Significant concern</option>
              <option value="severe">Severe — Serious misconduct</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Incident Date <span style="color:var(--danger);">*</span></label>
          <input type="date" name="incident_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d'); ?>" required>
        </div>

        <div class="form-group">
          <label class="form-label">Description <span style="color:var(--danger);">*</span></label>
          <textarea name="description" class="form-control" rows="6" placeholder="Provide a detailed, factual description of what happened. Include dates, times, witnesses and any other relevant information. Minimum 30 characters." required minlength="30"></textarea>
        </div>

        <div class="form-group">
          <label class="form-label">Supporting Evidence</label>
          <input type="file" name="evidence_file" class="form-control" accept="image/*,.pdf,.doc,.docx">
          <span class="form-text">Upload a photo, document or PDF as evidence (max 5MB)</span>
        </div>

        <div style="display:flex;gap:12px;justify-content:flex-end;margin-top:20px;">
          <a href="<?php echo site_url('dashboard/worker/'.$worker['id']); ?>" class="btn btn-outline">Cancel</a>
          <button type="submit" class="btn btn-danger">Submit Incident Report</button>
        </div>
      </form>
    </div>
  </div>
</div>
