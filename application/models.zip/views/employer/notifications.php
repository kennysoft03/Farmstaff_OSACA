<div style="max-width:720px;">
  <div class="card">
    <div class="card-header">
      <h5>🔔 Notifications</h5>
      <span style="font-size:.82rem;color:var(--gray-600);">All marked as read on open</span>
    </div>
    <div class="card-body" style="padding:0;">
      <?php if (empty($notifications)): ?>
        <div style="padding:48px;text-align:center;color:var(--gray-600);">
          <div style="font-size:3rem;margin-bottom:12px;">🔔</div>
          <p style="margin:0;">No notifications yet.</p>
        </div>
      <?php else: ?>
        <?php foreach ($notifications as $n): ?>
          <?php $colors=['info'=>'#0dcaf0','warning'=>'#ffc107','success'=>'#28a745','danger'=>'#dc3545']; ?>
          <div style="padding:16px 20px;border-bottom:1px solid var(--gray-200);display:flex;gap:14px;align-items:flex-start;background:<?php echo $n['is_read']?'#fff':'var(--green-pale)'; ?>;">
            <div style="width:10px;height:10px;border-radius:50%;background:<?php echo $colors[$n['type']]??'#aaa'; ?>;flex-shrink:0;margin-top:5px;"></div>
            <div style="flex:1;">
              <div style="font-weight:600;font-size:.9rem;"><?php echo htmlspecialchars($n['title']); ?></div>
              <div style="color:var(--gray-600);font-size:.85rem;margin-top:2px;"><?php echo htmlspecialchars($n['message']); ?></div>
              <div style="font-size:.75rem;color:var(--gray-500);margin-top:4px;"><?php echo date('d M Y, g:i A', strtotime($n['created_at'])); ?></div>
            </div>
            <?php if (!empty($n['link'])): ?>
              <a href="<?php echo site_url($n['link']); ?>" class="btn btn-outline btn-sm" style="flex-shrink:0;">View →</a>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</div>
