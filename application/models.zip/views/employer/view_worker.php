<?php
$ts    = (float)$worker['trust_score'];
$ring  = $ts >= 70 ? 'high' : ($ts >= 40 ? 'medium' : 'low');
$score = number_format($ts, 0);
?>
<div style="margin-bottom:16px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
  <a href="<?php echo site_url('dashboard/workers'); ?>" class="btn btn-outline btn-sm">← Workers</a>
  <a href="<?php echo site_url('dashboard/worker/'.$worker['id'].'/edit'); ?>" class="btn btn-outline btn-sm">✏️ Edit</a>
  <a href="<?php echo site_url('dashboard/worker/'.$worker['id'].'/history'); ?>" class="btn btn-outline btn-sm">📋 Work History</a>
  <a href="<?php echo site_url('dashboard/worker/'.$worker['id'].'/skills'); ?>" class="btn btn-outline btn-sm">🏆 Skills</a>
  <a href="<?php echo site_url('dashboard/worker/'.$worker['id'].'/attendance'); ?>" class="btn btn-outline btn-sm">📅 Attendance</a>
  <a href="<?php echo site_url('dashboard/worker/'.$worker['id'].'/incident'); ?>" class="btn btn-outline btn-sm" style="color:var(--danger);border-color:var(--danger);">⚠️ Report Incident</a>
  <a href="<?php echo site_url('dashboard/worker/'.$worker['id'].'/rate'); ?>" class="btn btn-gold btn-sm">⭐ Rate Worker</a>
</div>

<div style="display:grid;grid-template-columns:1fr 2fr;gap:20px;align-items:start;flex-wrap:wrap;">
  <!-- Left: Profile card -->
  <div>
    <div class="card">
      <div style="background:linear-gradient(135deg,var(--green-dark),#2d7a3e);padding:24px;text-align:center;border-radius:12px 12px 0 0;">
        <div style="width:80px;height:80px;border-radius:50%;background:rgba(255,255,255,.2);border:3px solid rgba(255,255,255,.6);display:flex;align-items:center;justify-content:center;font-size:2rem;margin:0 auto 12px;overflow:hidden;">
          <?php if (!empty($worker['photo'])): ?>
            <img src="<?php echo base_url($worker['photo']); ?>" style="width:100%;height:100%;object-fit:cover;">
          <?php else: ?>👤<?php endif; ?>
        </div>
        <h4 style="color:#fff;margin:0 0 4px;"><?php echo htmlspecialchars($worker['firstname'].' '.$worker['lastname']); ?></h4>
        <span class="worker-id-pill" style="background:rgba(255,255,255,.25);"><?php echo htmlspecialchars($worker['worker_id']); ?></span>
      </div>
      <div class="card-body" style="padding:20px;">
        <div style="text-align:center;margin-bottom:16px;">
          <div class="trust-score-ring <?php echo $ring; ?>" style="margin:0 auto;"><?php echo $score; ?><span style="font-size:.6rem;">/100</span></div>
          <div style="font-size:.75rem;color:var(--gray-600);margin-top:6px;">Trust Score</div>
        </div>
        <?php
        $fields = [
          'Phone'     => $worker['phone'],
          'Alt Phone' => $worker['alt_phone'],
          'Email'     => $worker['email'],
          'Gender'    => ucfirst($worker['gender'] ?? ''),
          'DOB'       => !empty($worker['dob']) ? date('d M Y', strtotime($worker['dob'])) : '',
          'LGA'       => $worker['lga'],
          'ID Type'   => $worker['id_type'],
          'ID No.'    => $worker['id_number'],
        ];
        foreach ($fields as $label => $val):
          if (empty($val)) continue; ?>
          <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--gray-200);font-size:.85rem;">
            <span style="color:var(--gray-600);"><?php echo $label; ?></span>
            <span style="font-weight:600;text-align:right;"><?php echo htmlspecialchars($val); ?></span>
          </div>
        <?php endforeach; ?>

        <div style="margin-top:14px;">
          <?php $sc=['active'=>'badge-success','inactive'=>'badge-secondary','flagged'=>'badge-warning','suspended'=>'badge-danger'];?>
          <div style="text-align:center;"><span class="badge <?php echo $sc[$worker['status']]??'badge-secondary'; ?>" style="font-size:.88rem;padding:6px 16px;"><?php echo strtoupper($worker['status']); ?></span></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Right: Tabs -->
  <div style="display:flex;flex-direction:column;gap:20px;">

    <!-- Attendance Summary -->
    <div class="card">
      <div class="card-header"><h5>📅 Attendance Summary</h5></div>
      <div class="card-body">
        <?php if (!empty($att_summary['total'])): ?>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;text-align:center;margin-bottom:14px;">
          <?php foreach(['total'=>['Total','var(--gray-800)'],'present'=>['Present','var(--green-dark)'],'late'=>['Late','var(--gold)'],'absent'=>['Absent','var(--danger)']] as $k=>[$label,$color]): ?>
          <div><div style="font-size:1.4rem;font-weight:800;color:<?php echo $color; ?>;"><?php echo $att_summary[$k]??0; ?></div><div style="font-size:.75rem;color:var(--gray-600);"><?php echo $label; ?></div></div>
          <?php endforeach; ?>
        </div>
        <div style="margin-bottom:6px;display:flex;justify-content:space-between;font-size:.82rem;"><span>Attendance Score</span><strong><?php echo $att_summary['score']??0; ?>%</strong></div>
        <div class="att-bar"><div class="att-bar-fill" style="width:<?php echo $att_summary['score']??0; ?>%;"></div></div>
        <?php else: ?>
          <p style="color:var(--gray-600);font-size:.88rem;margin:0;">No attendance records yet. <a href="<?php echo site_url('dashboard/worker/'.$worker['id'].'/attendance'); ?>">Log attendance →</a></p>
        <?php endif; ?>
      </div>
    </div>

    <!-- Work History -->
    <div class="card">
      <div class="card-header">
        <h5>📋 Work History</h5>
        <a href="<?php echo site_url('dashboard/worker/'.$worker['id'].'/add-history'); ?>" class="btn btn-outline btn-sm">+ Add</a>
      </div>
      <div class="table-responsive">
        <?php if (empty($work_history)): ?>
          <p style="padding:16px;color:var(--gray-600);margin:0;">No work history recorded.</p>
        <?php else: ?>
        <table class="table">
          <thead><tr><th>Role</th><th>Farm</th><th>Period</th><th>Status</th></tr></thead>
          <tbody>
            <?php foreach ($work_history as $h): ?>
            <tr>
              <td style="font-weight:600;font-size:.88rem;"><?php echo htmlspecialchars($h['role']); ?></td>
              <td style="font-size:.85rem;"><?php echo htmlspecialchars($h['farm_name']??'—'); ?></td>
              <td style="font-size:.82rem;">
                <?php echo date('M Y',strtotime($h['start_date'])); ?> —
                <?php echo $h['is_current'] ? '<strong style="color:var(--green-dark);">Present</strong>' : date('M Y', strtotime($h['end_date'])); ?>
              </td>
              <td><span class="badge <?php echo $h['status']==='active'?'badge-success':'badge-secondary'; ?>"><?php echo $h['status']; ?></span></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <?php endif; ?>
      </div>
    </div>

    <!-- Skills -->
    <div class="card">
      <div class="card-header">
        <h5>🏆 Skills</h5>
        <a href="<?php echo site_url('dashboard/worker/'.$worker['id'].'/skills'); ?>" class="btn btn-outline btn-sm">Manage</a>
      </div>
      <div class="card-body">
        <?php if (empty($skills)): ?>
          <p style="color:var(--gray-600);font-size:.88rem;margin:0;">No skills recorded yet.</p>
        <?php else: ?>
          <?php foreach ($skills as $s): ?>
            <span class="skill-tag <?php echo $s['verified']?'verified':''; ?>" title="<?php echo $s['verified']?'Verified':'Unverified'; ?>">
              <?php echo htmlspecialchars($s['skill_name']); ?>
              <span style="font-size:.7rem;opacity:.7;">(<?php echo str_repeat('★', (int)$s['rating']); ?>)</span>
            </span>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

    <!-- Incidents -->
    <?php if (!empty($incidents)): ?>
    <div class="card">
      <div class="card-header"><h5 style="color:var(--danger);">⚠️ Incidents (<?php echo count($incidents); ?>)</h5></div>
      <div class="table-responsive">
        <table class="table">
          <thead><tr><th>Type</th><th>Date</th><th>Severity</th><th>Status</th></tr></thead>
          <tbody>
            <?php foreach ($incidents as $inc): ?>
            <tr>
              <td style="font-size:.88rem;"><?php echo htmlspecialchars($inc['incident_type']); ?></td>
              <td style="font-size:.82rem;"><?php echo date('d M Y', strtotime($inc['incident_date'])); ?></td>
              <td><span class="badge <?php echo $inc['severity']==='severe'?'badge-danger':($inc['severity']==='moderate'?'badge-warning':'badge-info'); ?>"><?php echo $inc['severity']; ?></span></td>
              <td><span class="badge <?php echo $inc['status']==='accepted'?'badge-danger':($inc['status']==='pending'?'badge-warning':'badge-success'); ?>"><?php echo $inc['status']; ?></span></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>

    <!-- Performance Ratings -->
    <?php if (!empty($ratings)): ?>
    <div class="card">
      <div class="card-header"><h5>⭐ Performance Ratings</h5></div>
      <div class="card-body">
        <?php foreach (array_slice($ratings, 0, 3) as $r): ?>
        <div style="padding:12px 0;border-bottom:1px solid var(--gray-200);">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
            <span style="font-weight:600;font-size:.88rem;"><?php echo htmlspecialchars($r['farm_name']??''); ?></span>
            <span style="color:var(--gold);"><?php echo str_repeat('★',(int)$r['overall_rating']); ?><?php echo str_repeat('☆',5-(int)$r['overall_rating']); ?></span>
          </div>
          <?php if (!empty($r['review_text'])): ?>
            <p style="margin:0;font-size:.82rem;color:var(--gray-600);"><?php echo htmlspecialchars($r['review_text']); ?></p>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

  </div>
</div>
